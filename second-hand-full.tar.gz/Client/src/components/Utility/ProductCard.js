import React, { useState } from "react";
import { FaShoppingCart } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/authContext";

const ProductCard = ({ product }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [clickedButtonId, setClickedButtonId] = useState(null);
  const isOwner = user && user.id === product.uploadedBy._id;

  const handleAddToCart = (product) => {
    setClickedButtonId(product._id);
    setTimeout(() => {
      setClickedButtonId(null);
    }, 1000); // Change the delay time as needed
    navigate(`/product/${product._id}`);
  };

  return (
    <div className="m-2 flex flex-col justify-between flex-shrink-0 w-64 bg-gray-900 text-white px-4 py-5 rounded-md hover:scale-105 transition-all">
      <a href={`/product/${product._id}`} className="text-blue-500 block ">
        <div
          className="w-full h-52 mb-2 rounded-md"
          style={{
            backgroundImage: `url(${product.images[0]})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        ></div>
      </a>
      <h3 className="text-lg font-semibold mb-1">
        {product.name.length > 40
          ? `${product.name.slice(0, 40)}...`
          : product.name}
      </h3>
      <div className="flex items-center justify-between mb-1">
        <p className="text-sm text-gray-300">
          Uploaded by - {product.uploadedBy.name}
        </p>
        <p className="text-sm text-gray-400">
          库存: {product.quantity || 0}
        </p>
      </div>
      <p className="text-sm text-gray-300">{product.uploadedBy.college}</p>

      <div className="flex justify-between items-center mt-2">
        {isOwner ? (
          <button
            className="flex items-center px-4 py-2 rounded bg-gray-600 text-gray-300 cursor-not-allowed"
            disabled
          >
            <span className="mr-2"><FaShoppingCart /></span>
            我的商品
          </button>
        ) : (
          <button
            className={`flex items-center px-4 py-2 rounded ${
              product.status === "sold_out" || product.quantity <= 0
                ? "bg-gray-400 cursor-not-allowed"
                : clickedButtonId === product._id
                ? "bg-green-500"
                : "bg-yellow-500 hover:bg-yellow-600"
            } text-gray-800 transition duration-300 transform`}
            onClick={() => {
              if (product.status !== "sold_out" && product.quantity > 0) {
                handleAddToCart(product);
              } else {
                alert("该商品已售罄");
              }
            }}
            disabled={product.status === "sold_out" || product.quantity <= 0}
          >
            <span
              className={`mr-2 ${
                clickedButtonId === product._id ? "animate-ping" : ""
              } transition-transform`}
            >
              <FaShoppingCart />
            </span>
            {product.status === "sold_out" || product.quantity <= 0
              ? "已售罄"
              : "Buy now"}
          </button>
        )}
        <p className="text-xl mx-auto">
          ₹{parseFloat(product.price.$numberDecimal).toFixed(2)}
        </p>
      </div>
    </div>
  );
};

export default ProductCard;
